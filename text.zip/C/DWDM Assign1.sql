create table DIM_Item(
  ID_Item int,
  ItemName varchar(20),
  color varchar(10),
  price float,
  primary key(ID_Item)
);

create table DIM_Place(
  ID_Place int,
  ShopName varchar(20),
  city varchar(20),
  Country varchar(3),
  primary key(ID_Place)
);

create table DIM_Time(
  ID_Time int,
  RealDate date,
  YearMonth varchar(8),
  primary key(ID_Time)
);

create table FACT_Sale(
  ID_Sale varchar(5),
  Total float,
  ID_Item int,
  ID_Place int,
  ID_Time int,
  foreign key (ID_Item) references DIM_Item(ID_Item),
  foreign key (ID_Place) references DIM_Place(ID_Place),
  foreign key (ID_Time) references DIM_Time(ID_Time)
);

insert into DIM_Item values(101,'I20','White',800000);
insert into DIM_Item values(102,'BMW','Black',8000000);
insert into DIM_Item values(103,'Ford','Red',1800000);
insert into DIM_Item values(104,'Mustang','Grey',800000);
insert into DIM_Item values(105,'Agera','White',9000000);

insert into DIM_Place values(201,'CarsHome','Pune','IND');
insert into DIM_Place values(202,'Cars24','Tokyo','JPN');
insert into DIM_Place values(203,'CarShop','London','ENG');
insert into DIM_Place values(204,'Cars','Sydney','AUS');
insert into DIM_Place values(205,'AllAboutCars','Berlin','GER');

insert into DIM_Time values(301,to_date('04/09/2019' , 'DD/MM/YYYY'),'2019-SEP');
insert into DIM_Time values(302,to_date('04/08/2019' , 'DD/MM/YYYY'),'2019-AUG');
insert into DIM_Time values(303,to_date('04/07/2019' , 'DD/MM/YYYY'),'2019-JUL');
insert into DIM_Time values(304,to_date('04/06/2019' , 'DD/MM/YYYY'),'2019-JUN');
insert into DIM_Time values(305,to_date('04/05/2019' , 'DD/MM/YYYY'),'2019-MAY');

insert into FACT_Sale values('1001',100000000,101,201,301);
insert into FACT_Sale values('1002',10000,101,202,305);
insert into FACT_Sale values('1003',100000,101,203,301);
insert into FACT_Sale values('1004',10000000,101,204,302);
insert into FACT_Sale values('1005',10000000,101,205,303);
insert into FACT_Sale values('1006',10000000,102,201,304);
insert into FACT_Sale values('1007',1000,102,201,305);
insert into FACT_Sale values('1008',10000000,102,201,301);
insert into FACT_Sale values('1009',300000000,102,203,302);
insert into FACT_Sale values('1010',400000000,102,201,303);
insert into FACT_Sale values('1011',500000000,103,201,304);
insert into FACT_Sale values('1012',600000000,103,204,305);
insert into FACT_Sale values('1013',700000000,104,201,301);
insert into FACT_Sale values('1014',800000000,104,201,302);
insert into FACT_Sale values('1015',900000000,105,201,303);
insert into FACT_Sale values('1016',100000000,105,205,304);
insert into FACT_Sale values('1017',1000,105,201,305);

select ID_Item,ID_Place,sum(total)
from FACT_Sale
group by rollup(ID_Item,ID_Place)
order by ID_Item,ID_Place;


select DIM_Item.ItemName,DIM_Place.ShopName,sum(total)
from FACT_Sale,DIM_Item,DIM_Place
where FACT_Sale.ID_Item=DIM_Item.ID_Item and FACT_Sale.ID_Place=DIM_Place.ID_Place
group by rollup(DIM_Item.ItemName,DIM_Place.ShopName)
order by DIM_Item.ItemName,DIM_Place.ShopName;

select DIM_Item.ItemName,DIM_Place.City,DIM_Time.YearMonth,sum(total)
from FACT_Sale,DIM_Item,DIM_Place,DIM_Time
where FACT_Sale.ID_Item=DIM_Item.ID_Item and FACT_Sale.ID_Place=DIM_Place.ID_Place and FACT_Sale.ID_Time=DIM_Time.ID_Time
group by rollup(DIM_Item.ItemName,DIM_Place.City,DIM_Time.YearMonth)
order by DIM_Item.ItemName,DIM_Place.City,DIM_Time.YearMonth;

select DIM_Item.Color,DIM_Place.Country,DIM_Time.YearMonth,sum(total)
from FACT_Sale,DIM_Item,DIM_Place,DIM_Time
where FACT_Sale.ID_Item=DIM_Item.ID_Item and FACT_Sale.ID_Place=DIM_Place.ID_Place and FACT_Sale.ID_Time=DIM_Time.ID_Time
group by rollup(DIM_Item.Color,DIM_Place.Country,DIM_Time.YearMonth)
order by DIM_Item.Color,DIM_Place.Country,DIM_Time.YearMonth;



select ID_Item,ID_Place,sum(total)
from FACT_Sale
group by cube(ID_Item,ID_Place)
order by ID_Item,ID_Place;

select DIM_Item.ItemName,DIM_Place.ShopName,sum(total)
from FACT_Sale,DIM_Item,DIM_Place
where FACT_Sale.ID_Item=DIM_Item.ID_Item and FACT_Sale.ID_Place=DIM_Place.ID_Place
group by cube(DIM_Item.ItemName,DIM_Place.ShopName)
order by DIM_Item.ItemName,DIM_Place.ShopName;

select DIM_Item.ItemName,DIM_Place.City,DIM_Time.YearMonth,sum(total)
from FACT_Sale,DIM_Item,DIM_Place,DIM_Time
where FACT_Sale.ID_Item=DIM_Item.ID_Item and FACT_Sale.ID_Place=DIM_Place.ID_Place and FACT_Sale.ID_Time=DIM_Time.ID_Time
group by cube(DIM_Item.ItemName,DIM_Place.City,DIM_Time.YearMonth)
order by DIM_Item.ItemName,DIM_Place.City,DIM_Time.YearMonth;

select DIM_Item.Color,DIM_Place.Country,DIM_Time.YearMonth,sum(total)
from FACT_Sale,DIM_Item,DIM_Place,DIM_Time
where FACT_Sale.ID_Item=DIM_Item.ID_Item and FACT_Sale.ID_Place=DIM_Place.ID_Place and FACT_Sale.ID_Time=DIM_Time.ID_Time
group by cube(DIM_Item.Color,DIM_Place.Country,DIM_Time.YearMonth)
order by DIM_Item.Color,DIM_Place.Country,DIM_Time.YearMonth;

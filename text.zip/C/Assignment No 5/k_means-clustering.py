# -*- coding: utf-8 -*-
"""
Created on Tue Nov  5 14:02:36 2019

@author: Swapnil
"""

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd



dataset = pd.read_csv('iris.csv')
X = dataset.iloc[:,0:4].values
y = dataset.iloc[:,[4]].values
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
labelencoder_y = LabelEncoder()
y = labelencoder_y.fit_transform(y)

# Splitting the dataset into the Training set and Test set
"""from sklearn.cross_validation import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 0)"""

# Feature Scaling
"""from sklearn.preprocessing import StandardScaler
sc_X = StandardScaler()
X_train = sc_X.fit_transform(X_train)
X_test = sc_X.transform(X_test)
sc_y = StandardScaler()
y_train = sc_y.fit_transform(y_train)"""

from sklearn.cluster import KMeans
wcss = []
for i in range(1, 11):
    kmeans = KMeans(n_clusters = i, init = 'k-means++', random_state = 42)
    kmeans.fit(X)
    wcss.append(kmeans.inertia_)
plt.plot(range(1, 11), wcss)
plt.title('The Elbow Method')
plt.xlabel('Number of clusters')
plt.ylabel('WCSS')
plt.show()

kmeans = KMeans(n_clusters = 3, init = 'k-means++', random_state = 42)
y_kmeans = kmeans.fit_predict(X)
for i in range(0,len(y_kmeans)):
    if y_kmeans[i]==1:
        y_kmeans[i]=0
    elif y_kmeans[i]==0:
        y_kmeans[i]=1

plt.scatter(X[y_kmeans == 0, 0], X[y_kmeans == 0, 2], s = 100, c = 'red', label = 'Cluster 1')
plt.scatter(X[y_kmeans == 1, 0], X[y_kmeans == 1, 2], s = 100, c = 'blue', label = 'Cluster 2')
plt.scatter(X[y_kmeans == 2, 0], X[y_kmeans == 2, 2], s = 100, c = 'green', label = 'Cluster 3')
plt.scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:, 1],kmeans.cluster_centers_[:, 2], s = 300, c = 'yellow', label = 'Centroids')
plt.legend()
plt.show()
from sklearn.metrics import confusion_matrix,accuracy_score
cm = confusion_matrix(y, y_kmeans )
accuracy = accuracy_score(y, y_kmeans)
print("K-means accuracy")
print(accuracy)
print("K-means  confusion matrix")
print(cm)
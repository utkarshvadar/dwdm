#!/usr/bin/env python
# coding: utf-8

# In[3]:


#import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


# In[4]:


class NaiveBayesClassifier(object):
    
    def __init__(self):
        pass
    
    def fit(self, X, y):
        self.X_train = X
        self.y_train = y    
        self.no_of_classes = np.max(self.y_train) + 1
         
    def euclidianDistance(self, Xtest, Xtrain):
        return np.sqrt(np.sum(np.power((Xtest - Xtrain), 2)))
       
    # 1. calculate Prior probability. Ex. P(A) = No_of_elements_of_one_class / total_no_of_samples
    # 2. calculate Margin probability P(X) = No_of_elements_in_radius / total_no_of_samples
    # 3. calculate Likeliyhood (P(X|A) = No_of_elements_of_current_class / total_no_of_samples
    # 4. calculate Posterior probability: P(A|X) = (P(X|A) * P(A)) / P(X)
    def predict(self, X, radius=0.4):   
        pred = []
    
        members_of_class = []
        for i in range(self.no_of_classes):
            counter = 0
            for j in range(len(self.y_train)):
                if self.y_train[j] == i:
                    counter += 1
            members_of_class.append(counter)
        
        #Entering the process of prediction
        for t in range(len(X)):
            prob_of_classes = []
            for i in range(self.no_of_classes):
                #1
                prior_prob = members_of_class[i]/len(self.y_train)
                #2
                inRadius_no = 0
                inRadius_no_current_class = 0
                
                for j in range(len(self.X_train)):
                    if self.euclidianDistance(X[t], self.X_train[j]) < radius:
                        inRadius_no += 1
                        if self.y_train[j] == i:
                            inRadius_no_current_class += 1
                #Computing, margin probability
                margin_prob = inRadius_no/len(self.X_train)
                #3
                likelihood = inRadius_no_current_class/len(self.X_train)
                #4
                post_prob = (likelihood * prior_prob)/margin_prob
                prob_of_classes.append(post_prob)
            
            pred.append(np.argmax(prob_of_classes))    
        return pred
    


# In[5]:


def accuracy(y_tes, y_pred):
    correct = 0
    for i in range(len(y_pred)):
        if(y_tes[i] == y_pred[i]):
            correct += 1
    return (correct/len(y_tes))*100


# In[8]:


#Testing Breast Cancer dataset
def breastCancerTest():
    dataset = pd.read_csv('breastCancer.csv')
    dataset.replace('?', 0, inplace=True)
    dataset = dataset.applymap(np.int64)
    X = dataset.iloc[:, 1:-1].values    
    y = dataset.iloc[:, -1].values
    
    y_new = []
    for i in range(len(y)):
        if y[i] == 2:
            y_new.append(0)
        else:
            y_new.append(1)
    y_new = np.array(y_new)

    from sklearn.model_selection import train_test_split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.25, random_state = 0)

    
    NB = NaiveBayesClassifier()
    NB.fit(X_train, y_train)
    y_pred = NB.predict(X_test, radius=8)
    
    print('-------TEST-------')
    dict_classes = {2:'Benign', 4:'Malignant'}
    for j in range(len(y_pred)):
       if j%10==0:
            print('%20s %20s' % (dict_classes[y_test[j]], dict_classes[y_pred[j]]))

    print("Accuracy for my Naive Bayes Classifier: ", accuracy(y_test, y_pred), "%")


# In[9]:


breastCancerTest()


# In[ ]:





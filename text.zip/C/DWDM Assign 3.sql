
Create table DimCustomer
(
CustomerID int primary key,
CustomerAltID varchar(10) not null,
CustomerName varchar(50),
Gender varchar(20)
);

Insert into DimCustomer(CustomerID,CustomerAltID,CustomerName,Gender)values(1,'IMI-001','Henry Ford','M');
Insert into DimCustomer(CustomerID,CustomerAltID,CustomerName,Gender)values(2,'IMI-002','Bill Gates','M');
Insert into DimCustomer(CustomerID,CustomerAltID,CustomerName,Gender)values(3,'IMI-003','Muskan Shaikh','F');
Insert into DimCustomer(CustomerID,CustomerAltID,CustomerName,Gender)values(4,'IMI-004','Richard Thrubin','M');
Insert into DimCustomer(CustomerID,CustomerAltID,CustomerName,Gender)values(5,'IMI-005','Emma Wattson','F');

Create table DimProduct
(
ProductKey int primary key,
ProductAltKey varchar(10)not null,
ProductName varchar(100),
ProductActualCost real,
ProductSalesCost real
);

Insert into DimProduct(ProductKey,ProductAltKey,ProductName, ProductActualCost, ProductSalesCost)values(101,'ITM-001','Wheat Floor 1kg',5.50,6.50);
Insert into DimProduct(ProductKey,ProductAltKey,ProductName, ProductActualCost, ProductSalesCost)values(102,'ITM-002','Rice Grains 1kg',22.50,24);
Insert into DimProduct(ProductKey,ProductAltKey,ProductName, ProductActualCost, ProductSalesCost)values(103,'ITM-003','SunFlower Oil 1 ltr',42,43.5);
Insert into DimProduct(ProductKey,ProductAltKey,ProductName, ProductActualCost, ProductSalesCost)values(104,'ITM-004','Nirma Soap',18,20);
Insert into DimProduct(ProductKey,ProductAltKey,ProductName, ProductActualCost, ProductSalesCost)values(105,'ITM-005','Arial Washing Powder 1kg',135,139);

Create table DimStores
(
StoreID int primary key,
StoreAltID varchar(10)not null,
StoreName varchar(100),
StoreLocation varchar(100),
City varchar(100),
State varchar(100),
Country varchar(100)
);

Insert into DimStores(StoreID,StoreAltID,StoreName,StoreLocation,City,State,Country )values(501,'LOC-A1','X-Mart','S.P. RingRoad','Ahmedabad','Guj','India');
Insert into DimStores(StoreID,StoreAltID,StoreName,StoreLocation,City,State,Country )values(502,'LOC-A2','X-Mart','Maninagar','Ahmedabad','Guj','India');
Insert into DimStores(StoreID,StoreAltID,StoreName,StoreLocation,City,State,Country )values(503,'LOC-A3','X-Mart','Sivranjani','Ahmedabad','Guj','India');


Create table DimSalesPerson
(
SalesPersonID int primary key,
SalesPersonAltID varchar(10)not null,
SalesPersonName varchar(100),
StoreID int,
City varchar(100),
State varchar(100),
Country varchar(100)
);

Insert into DimSalesPerson(SalesPersonID,SalesPersonAltID,SalesPersonName,StoreID,City,State,Country )values
(11,'SP-DMSPR1','Ashish',1,'Ahmedabad','Guj','India');
Insert into DimSalesPerson(SalesPersonID,SalesPersonAltID,SalesPersonName,StoreID,City,State,Country )values
(12,'SP-DMSPR2','Ketan',1,'Ahmedabad','Guj','India');
Insert into DimSalesPerson(SalesPersonID,SalesPersonAltID,SalesPersonName,StoreID,City,State,Country )values
(13,'SP-DMNGR1','Srinivas',2,'Ahmedabad','Guj','India');
Insert into DimSalesPerson(SalesPersonID,SalesPersonAltID,SalesPersonName,StoreID,City,State,Country )values
(14,'SP-DMNGR2','Saad',2,'Ahmedabad','Guj','India');
Insert into DimSalesPerson(SalesPersonID,SalesPersonAltID,SalesPersonName,StoreID,City,State,Country )values
(15,'SP-DMSVR1','Jasmin',3,'Ahmedabad','Guj','India');
Insert into DimSalesPerson(SalesPersonID,SalesPersonAltID,SalesPersonName,StoreID,City,State,Country )values
(16,'SP-DMSVR2','Jacob',3,'Ahmedabad','Guj','India');

CREATE TABLE DimTime(
	TimeKey int NOT NULL,
	TimeAltKey int NOT NULL,
	Time30 varchar(8) NOT NULL,
	Hour30 int NOT NULL,
	MinuteNumber int NOT NULL,
	SecondNumber int NOT NULL,
	TimeInSecond int NOT NULL,
	HourlyBucket varchar(15)not null,
	DayTimeBucketGroupKey int not null,
	DayTimeBucket varchar(100) not null
);

INSERT INTO DimTime (TimeKey,TimeAltKey, Time30,Hour30,MinuteNumber, SecondNumber, TimeInSecond,HourlyBucket, DayTimeBucketGroupKey,DayTimeBucket)
values(1,30000,'3:00:00',3,00,00,10800,'3:00-3:59',1,'Early Morning(03:00 AM To 6:59 AM)');

INSERT INTO DimTime (TimeKey,TimeAltKey, Time30,Hour30,MinuteNumber, SecondNumber, TimeInSecond,HourlyBucket, DayTimeBucketGroupKey,DayTimeBucket)
values(2,121000,'12:10:00',12,10,00,43800,'12:00-12:59',4,'Lunch (12:00 PM To 13:59 PM)');


Create Table FactProductSales
(
	TransactionId bigint primary key,
	SalesInvoiceNumber int not null,
	SalesDateKey int,
	SalesTimeKey int,
	SalesTimeAltKey int,
	StoreID int not null,
	CustomerID int not null,
	ProductID int not null,
	SalesPersonID int not null,
	Quantity float,
	SalesTotalCost money,
	ProductActualCost money,
	Deviation float,
	FOREIGN KEY (StoreID)REFERENCES DimStores(StoreID),
	FOREIGN KEY (CustomerID)REFERENCES Dimcustomer(CustomerID),
	FOREIGN KEY (ProductID)REFERENCES Dimproduct(ProductKey),
	FOREIGN KEY (SalesPersonID)REFERENCES Dimsalesperson(SalesPersonID),
	FOREIGN KEY (SalesDateKey)REFERENCES DimDate(DateKey),
	FOREIGN KEY (SalesTimeKey)REFERENCES DimDate(TimeKey)
);

INSERT INTO FactProductSales values(1,20130101,44347,121907,1,1,1,1,2,11,13,501,1,101,11,1,1);

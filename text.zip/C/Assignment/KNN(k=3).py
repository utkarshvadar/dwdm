
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np

import matplotlib.pyplot as plt

ds=pd.read_csv("iris.csv")

x=ds.iloc[:,0:4].values
y=ds.iloc[:,4].values


# In[2]:


from sklearn.preprocessing import LabelEncoder,OneHotEncoder
ly=LabelEncoder()
y=ly.fit_transform(y)


# In[3]:


from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.20,random_state=0)


# In[4]:


from sklearn.preprocessing import StandardScaler
sc=StandardScaler()
x_train=sc.fit_transform(x_train)
x_test=sc.transform(x_test)


# In[5]:


from sklearn.neighbors import KNeighborsClassifier
cls=KNeighborsClassifier(n_neighbors=3)
cls.fit(x_train,y_train)
y_pred=cls.predict(x_test)


# In[6]:


from sklearn.metrics import confusion_matrix,accuracy_score,classification_report
cm=confusion_matrix(y_test,y_pred)
score=accuracy_score(y_test,y_pred)
print(cm)
print(score)


# In[7]:


from sklearn.model_selection import cross_val_score
accuracies = cross_val_score(estimator = cls, X = x_train, y = y_train, cv = 10)
accuracies.mean()


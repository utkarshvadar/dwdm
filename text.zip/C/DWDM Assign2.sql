//Headquarter Database
create table Customer2
(
    Customer_id number(10) primary key,
    Customer_name varchar(20),
    City_id number(10),
    First_order_date DATE,
    Foreign Key(City_id) references Headquarters(City_id)
);

INSERT INTO Customer2 values(11,'Sourabh',501,'14-SEP-2019');
INSERT INTO Customer2 values(12,'Pratik',502,'12-JUL-2019');
INSERT INTO Customer2 values(13,'Abhishek',503,'13-SEP-2019');
INSERT INTO Customer2 values(14,'Aditya',504,'14-JUL-2019');
INSERT INTO Customer2 values(15,'Utkarsh',505,'16-SEP-2019');

CREATE TABLE Walkin_customers
(
    Customer_id number(20),
    tourism_guide number,
    walkin_time TIMESTAMP,
    Foreign key(Customer_id) references Customer2(Customer_id)
);


INSERT INTO Walkin_customers values(11,101,TO_TIMESTAMP('14-SEP-2019 21:02:04','DD-MM-YYYY hh24:mi:ss'));
INSERT INTO Walkin_customers values(12,102,TO_TIMESTAMP('12-JUL-2019 11:12:33','DD-MM-YYYY hh24:mi:ss'));
INSERT INTO Walkin_customers values(13,103,TO_TIMESTAMP('13-SEP-2019 09:01:00','DD-MM-YYYY hh24:mi:ss'));
INSERT INTO Walkin_customers values(14,104,TO_TIMESTAMP('14-JUL-2019 18:02:24','DD-MM-YYYY hh24:mi:ss'));
INSERT INTO Walkin_customers values(15,105,TO_TIMESTAMP('16-SEP-2019 15:02:34','DD-MM-YYYY hh24:mi:ss'));


CREATE TABLE Mail_order_customers
(
    Customer_id number(20),
    post_address varchar(20),
    mail_order_time TIMESTAMP,
    Foreign key(Customer_id) references Customer2(Customer_id)
);

INSERT INTO Mail_order_customers values(11,'Sangli',TO_TIMESTAMP('14-SEP-2019 21:02:04','DD-MM-YYYY hh24:mi:ss'));
INSERT INTO Mail_order_customers values(12,'Phaltan',TO_TIMESTAMP('12-JUL-2019 11:12:33','DD-MM-YYYY hh24:mi:ss'));
INSERT INTO Mail_order_customers values(13,'Malakapur',TO_TIMESTAMP('13-SEP-2019 09:01:00','DD-MM-YYYY hh24:mi:ss'));
INSERT INTO Mail_order_customers values(14,'Satara',TO_TIMESTAMP('14-JUL-2019 18:02:24','DD-MM-YYYY hh24:mi:ss'));
INSERT INTO Mail_order_customers values(15,'Wardha',TO_TIMESTAMP('16-SEP-2019 15:02:34','DD-MM-YYYY hh24:mi:ss'));

//Sales Database
CREATE TABLE Headquarters
(
    City_id number(10) primary key,
    City_name varchar(20),
    Headquarter_addr varchar(20),
    h_state varchar(20),
    h_time TIMESTAMP
);
    
INSERT INTO Headquarters values(501,'Sangli','Narsobanagar','MH',TO_TIMESTAMP('14-SEP-2019 21:02:04','DD-MM-YYYY hh24:mi:ss'));
INSERT INTO Headquarters values(502,'Wardha','Akshatnagar','MH',TO_TIMESTAMP('12-JUL-2019 11:12:33','DD-MM-YYYY hh24:mi:ss'));
INSERT INTO Headquarters values(503,'Sangli','Vishrambag','MH',TO_TIMESTAMP('13-SEP-2019 09:01:00','DD-MM-YYYY hh24:mi:ss'));
INSERT INTO Headquarters values(504,'Phaltan','Kolki','MH',TO_TIMESTAMP('14-JUL-2019 18:02:24','DD-MM-YYYY hh24:mi:ss'));
INSERT INTO Headquarters values(505,'Pusad','laxminagar','MH',TO_TIMESTAMP('16-SEP-2019 15:02:34','DD-MM-YYYY hh24:mi:ss'));

CREATE TABLE Stores 
(
    Store_id number(10) primary key,
    City_id number(10),
    Phone number(10),
    s_time TIMESTAMP,
    Foreign key(City_id) references Headquarters(City_id)
);

INSERT INTO Stores values(701,501,8600197269,TO_TIMESTAMP('14-SEP-2019 21:02:04','DD-MM-YYYY hh24:mi:ss'));
INSERT INTO Stores values(702,502,8669008902,TO_TIMESTAMP('16-SEP-2019 15:14:00','DD-MM-YYYY hh24:mi:ss'));
INSERT INTO Stores values(703,503,9856234512,TO_TIMESTAMP('17-SEP-2019 11:13:15','DD-MM-YYYY hh24:mi:ss'));
INSERT INTO Stores values(704,504,7881564123,TO_TIMESTAMP('18-SEP-2019 01:12:24','DD-MM-YYYY hh24:mi:ss'));
INSERT INTO Stores values(705,505,8084524156,TO_TIMESTAMP('19-SEP-2019 15:18:04','DD-MM-YYYY hh24:mi:ss'));

CREATE TABLE Items
(
    Item_id number(10) primary key,
    i_description varchar(20),
    i_size number(10),
    i_weight number(10),
    unit_price REAL,
    i_time TIMESTAMP
);

INSERT INTO Items values(1,'computer',20,200,45000,TO_TIMESTAMP('14-SEP-2019 21:02:04','DD-MM-YYYY hh24:mi:ss'));
INSERT INTO Items values(2,'laptop',30,150,40000,TO_TIMESTAMP('16-SEP-2019 15:14:00','DD-MM-YYYY hh24:mi:ss'));
INSERT INTO Items values(3,'pen',2,200,30,TO_TIMESTAMP('17-SEP-2019 11:13:15','DD-MM-YYYY hh24:mi:ss'));
INSERT INTO Items values(4,'TV',21,200,20000,TO_TIMESTAMP('18-SEP-2019 01:12:24','DD-MM-YYYY hh24:mi:ss'));
INSERT INTO Items values(5,'Refrigator',25,200,15000,TO_TIMESTAMP('19-SEP-2019 15:18:04','DD-MM-YYYY hh24:mi:ss'));

CREATE TABLE Stored_Items
(
    Store_id number(10),
    Item_id number(10),
    Quantity_held number(10),
    st_time TIMESTAMP,
    Foreign key(Store_id) references Stores(Store_id),
    Foreign key(Item_id) references Items(Item_id)
);

INSERT INTO Stored_Items values(701,1,10,TO_TIMESTAMP('14-SEP-2019 21:02:04','DD-MM-YYYY hh24:mi:ss'));
INSERT INTO Stored_Items values(702,2,15,TO_TIMESTAMP('16-SEP-2019 15:14:00','DD-MM-YYYY hh24:mi:ss'));
INSERT INTO Stored_Items values(703,3,20,TO_TIMESTAMP('17-SEP-2019 11:13:15','DD-MM-YYYY hh24:mi:ss'));
INSERT INTO Stored_Items values(704,4,11,TO_TIMESTAMP('18-SEP-2019 01:12:24','DD-MM-YYYY hh24:mi:ss'));
INSERT INTO Stored_Items values(705,5,5,TO_TIMESTAMP('19-SEP-2019 15:18:04','DD-MM-YYYY hh24:mi:ss'));


CREATE TABLE OrderTable
(
    Order_no number(10) primary key,
    Order_date DATE,
    Customer_id number(10),
    Foreign key(Customer_id) references Customer2(Customer_id)
);


INSERT INTO OrderTable values(1,'14-SEP-2019',11);
INSERT INTO OrderTable values(2,'16-JUL-2019',12);
INSERT INTO OrderTable values(3,'18-SEP-2019',13);
INSERT INTO OrderTable values(4,'19-JUL-2019',14);
INSERT INTO OrderTable values(5,'14-SEP-2019',15);

CREATE TABLE Ordered_Item
(
    Order_no number(10),
    Item_id number(10),
    Quantity_ordered number(10),
    Ordered_price number(10),
    o_time TIMESTAMP,
    Foreign key(Order_no) references OrderTable(Order_no),
    Foreign key(Item_id) references Items(Item_id)
);

INSERT INTO Ordered_Item values(1,1,10,24000,TO_TIMESTAMP('19-SEP-2019 15:18:04','DD-MM-YYYY hh24:mi:ss'));
INSERT INTO Ordered_Item values(2,2,15,16000,TO_TIMESTAMP('14-SEP-2019 14:22:04','DD-MM-YYYY hh24:mi:ss'));
INSERT INTO Ordered_Item values(3,3,23,40000,TO_TIMESTAMP('15-SEP-2019 17:25:00','DD-MM-YYYY hh24:mi:ss'));
INSERT INTO Ordered_Item values(4,4,16,20000,TO_TIMESTAMP('16-SEP-2019 15:18:04','DD-MM-YYYY hh24:mi:ss'));
INSERT INTO Ordered_Item values(5,5,5,10000,TO_TIMESTAMP('17-SEP-2019 10:10:10','DD-MM-YYYY hh24:mi:ss'));


CREATE TABLE facts
(
     Foreign key(Customer_id) references Customer(Customer_id),
     Foreign key(Store_id) references Stores(Store_id),
     Foreign key(Item_id) references Items(Item_id),
     Foreign key(Order_no) references OrderTable(Order_no),
     Foreign key(City_id) references Headquarters(City_id)
     
);


SELECT h.City_name,h_state,phone,i_description,i_size,i_weight,unit_price
from Stored_items SI,Items I,Headquarters H ,Stores S
where SI.item_id=I.item_id and S.city_id= H.city_id and SI.store_id= S.store_id;


SELECT unique Customer_name,Order_date
from Customer2, OrderTable,Stores S ,Ordered_item O, Stored_items SI
where OrderTable.Order_no=O.Order_no and S.Store_id=SI.Store_id and Customer2.customer_id=OrderTable.Customer_id and SI.Item_id=O.Item_id;


SELECT S.store_id,H.City_name,S.Phone
FROM Stores S,Headquarters H, OrderTable O,Ordered_Item OI, Stored_Items SI, Customer2 C
WHERE C.Customer_id=O.Customer_id and O.Order_no=OI.Order_no and OI.Item_id=SI.Item_id and SI.Store_id=S.Store_id and S.City_id=H.City_id;

SELECT H.Headquarter_addr,H.City_name, H.h_state
FROM Headquarters H,Stored_Items SI, Stores S,Items I
WHERE H.City_id=S.City_id and SI.Store_id=S.Store_id and SI.Item_id=I.Item_id;

SELECT unique o.item_id,i_description,s.store_id,city_name
FROM Items, Stores, Stored_Items s, OrderTable,Ordered_Item o, Headquarters h, Customer
WHERE h.CITY_ID=Stores.CITY_ID and ITEMS.ITEM_ID=o.ITEM_ID and o.ITEM_ID=s.ITEM_ID and stores.store_id= s.store_id;

SELECT Customer_name,City_name,H.h_state 
from Customer2, Headquarters H
where H.city_id=Customer2.CITY_ID and Customer2.Customer_id=11;

SELECT sum(SI.Quantity_held), SI.Item_id
FROM Stores S, Stored_items SI,Headquarters H
WHERE H.City_name='Sangli' and H.City_id=S.City_id and SI.Store_id=S.Store_id and SI.Item_id=3
Group By(SI.Item_id);

SELECT unique Customer_name,city_id,Quantity_ordered,i_description,s.store_id
FROM OrderTable ,Customer2,Ordered_Item,Items, Stored_items s
WHERE OrderTable.Order_no =Ordered_Item.Order_no and Customer2.Customer_id=OrderTable.customer_id and Ordered_Item.Item_id= Items.Item_id and S.item_id= Items.item_id;

SELECT customer_id from Walkin_customers
UNION
select customer_id from Mail_order_customers;

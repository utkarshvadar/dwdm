import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.model_selection import train_test_split

data=pd.read_csv('iris.data')
x=data.iloc[:,:-1]
y=data.iloc[:,-1]

x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2)

model=KMeans(n_clusters=3)
model.fit(x_train)

print(model.labels_)
y_test=y_test.values
prediction=model.predict(x_test)
prediction=prediction.tolist()
count_0=prediction.count(0)
count_1=prediction.count(1)
count_2=prediction.count(2)

y_test=y_test.tolist()

count_vergi=y_test.count('Iris-virginica')
count_seto=y_test.count('Iris-setosa')
count_versi=y_test.count('Iris-versicolor')

print("cluster 0 : ",count_0)
print("cluster 1 : ",count_1)
print("cluster 2 : ",count_2)

print("Verginica : ",count_vergi)
print("Setosa : ",count_seto)
print("Versicolor : ",count_versi)

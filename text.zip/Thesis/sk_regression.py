from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
import seaborn as sb
import numpy as np
import pandas as pd

data=pd.read_csv('iris.data')
print(type(data))

X=data.iloc[:,:-1]
y=data.iloc[:,-1]

x_train, x_test, y_train, y_test=train_test_split(X,y,test_size=0.2,random_state=0)

model=LogisticRegression()
model.fit(x_train,y_train)

predictions=model.predict(x_test)
#print(predictions)
count=0
y_test=y_test.values
j=0
for i in predictions:
    if(i == y_test[j]):
        count+=1
    j=j+1
print(count/len(predictions))

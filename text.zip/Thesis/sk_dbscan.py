import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import DBSCAN
from sklearn.model_selection import train_test_split

data=pd.read_csv('iris.data')
x=data.iloc[:,:-1]
y=data.iloc[:,-1]

x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2)

model=DBSCAN(eps=0.5, min_samples=4)
model.fit(x_train)

print(model.labels_)
#print(model.predict(np.array([[3.2,5.8,1.9,6.8]])))

count=0


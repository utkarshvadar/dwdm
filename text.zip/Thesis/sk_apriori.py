import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from apyori import apriori

data=pd.read_csv('vote.txt')
data.head()


association_rules = apriori(data, min_support=0.0090, min_confidence=0.2, min_lift=5, min_length=2)
association_results = list(association_rules)
print(association_results)

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier

data= pd.read_csv('wdbc.data')

x= data.iloc[:,2:]
y= data.iloc[:,1:2]

x_train, x_test, y_train, y_test = train_test_split(x,y,test_size=0.2)


model= MLPClassifier(hidden_layer_sizes=(10,10,10), max_iter=1000)
model.fit(x_train, y_train.values.ravel())

y_pred= model.predict(x_test)

y_test = y_test.values

j=0
cnt=0

for i in y_pred:
    if ( i == y_test[j] ):
        cnt+=1
    j+=1
print(cnt/len(y_test))
    

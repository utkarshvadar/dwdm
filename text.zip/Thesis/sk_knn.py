import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier

data=sns.load_dataset('iris')
print(data)
x= data.iloc[:,:-1]
y= data.iloc[:,-1]

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2)

model= KNeighborsClassifier(n_neighbors=4)
model.fit(x_train, y_train)

y_pred= model.predict(x_test)

count=0
y_test= y_test.values

j=0

for i in y_pred:
    if i == y_test[j]:
        count+=1
    j=j+1
print(count/len(y_test))

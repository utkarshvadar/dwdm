import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import AgglomerativeClustering
from sklearn.model_selection import train_test_split


data=pd.read_csv('iris.data')
x=data.iloc[:,:-1]
y_train=data.iloc[:,-1]

cluster = AgglomerativeClustering(n_clusters=3, affinity='euclidean', linkage='ward')
cluster.fit(x)

print(cluster.labels_)
output=cluster.labels_
output=output.tolist()

count_0=output.count(0)
count_1=output.count(1)
count_2=output.count(2)

y_train=y_train.values
y_train=y_train.tolist()

count_vergi=y_train.count('Iris-virginica')
count_seto=y_train.count('Iris-setosa')
count_versi=y_train.count('Iris-versicolor')

print("cluster 0 : ",count_0)
print("cluster 1 : ",count_1)
print("cluster 2 : ",count_2)

print("Verginica : ",count_vergi)
print("Setosa : ",count_seto)
print("Versicolor : ",count_versi)

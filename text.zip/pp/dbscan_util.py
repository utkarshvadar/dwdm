import math

#class for datapoint
class Datapoint:
    count = 0
    def __init__(self,attr,op):
        self.attr = attr
        self.op = op
        Datapoint.count += 1
        
    def display(self):
        print(self.attr,' => ',self.op)

#load dataset
file = open('Iris.data','r')
lines = file.readlines()[:-1]
file.close()

dataset = []
for line in lines:
    op = line.split(',')[-1]
    attr = list(map(float,line.split(',')[:-1]))
    d1 = Datapoint(attr,op)
    dataset.append(d1)

def distance(d1,d2):
    d1 = d1.attr
    d2 = d2.attr
    dist = 0
    for i in range(len(d1)):
        dist += (d1[i]-d2[i])**2
    return math.sqrt(dist)


#function for k-nn avg distance
k=30
def kAverage(datapoint):
    dist_list=[]
    for d in dataset:
        dist_list.append(distance(d,datapoint))
    dist_list.sort()
    avg = 0
    for i in range(k):
        avg += dist_list[i]
    return (avg/k)


#main program
k_list = []
for datapoint in dataset:
    k_list.append(kAverage(datapoint))

k_list.sort()

print(k_list)

plot(k_list)

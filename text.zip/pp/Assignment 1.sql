create table dim_item
(
  id_item integer not null primary key,
  item_name char(20),
  color char(10),
  price number
);

create table dim_place
(
  id_place integer not null primary key,
  shopname char(20),
  city char(20),
  country char(20)
);

create table dim_time
(
  id_time integer not null primary key,
  realdate date,
  yearmonth char(8)
);

create table fact_sale
(
  id_sale char(5) not null primary key,
  total number,
  dim_item_id_item integer not null,
  dim_time_id_time integer not null,
  dim_place_id_place integer not null,
  foreign key(dim_item_id_item) references dim_item(id_item),  
  foreign key(dim_time_id_time) references dim_time(id_time),
  foreign key(dim_place_id_place) references dim_place(id_place)
);

insert into dim_item values(1,'Bicycle     ','green',2000);
insert into dim_item values(2,'Train     ','blue',5000);
insert into dim_item values(3,'Doll     ','red',200);
insert into dim_item values(4,'Kite     ','yellow',100);
insert into dim_item values(5,'Aeroplane     ','white',3000);

insert into dim_place values(100,'Rynaty     ','Sangli',2);
insert into dim_place values(101,'KexMon     ','NewYork',5);
insert into dim_place values(102,'Worbox     ','Pune',2);
insert into dim_place values(103,'Kwirfy     ','Miraj',2);
insert into dim_place values(104,'Rainbow     ','Canbera',2);

insert into dim_time values(200,to_date('23-08-18','DD-MM-RR'),'2018-AUG');
insert into dim_time values(201,to_date('15-07-19','DD-MM-RR'),'2019-JUL');
insert into dim_time values(202,to_date('26-12-07','DD-MM-RR'),'2007-DEC');
insert into dim_time values(203,to_date('04-02-19','DD-MM-RR'),'2019-FEB');
insert into dim_time values(204,to_date('08-01-15','DD-MM-RR'),'2015-JAN');


insert into fact_sale values('1000',178000, 1,204,100);
insert into fact_sale values('1001',475000, 2,203,101);
insert into fact_sale values('1002',191600, 3,202,102);
insert into fact_sale values('1003',90000, 4,201,103);
insert into fact_sale values('1004',258000, 5,200,104);
insert into fact_sale values('1005',135000, 5,200,104);
Insert into fact_sale (ID_SALE,TOTAL,DIM_ITEM_ID_ITEM,DIM_TIME_ID_TIME,DIM_PLACE_ID_PLACE) values ('1006 ',778900,4,201,103);
Insert into FACT_SALE (ID_SALE,TOTAL,DIM_ITEM_ID_ITEM,DIM_TIME_ID_TIME,DIM_PLACE_ID_PLACE) values ('1007 ',156800,3,202,102);
Insert into FACT_SALE (ID_SALE,TOTAL,DIM_ITEM_ID_ITEM,DIM_TIME_ID_TIME,DIM_PLACE_ID_PLACE) values ('1008 ',390000,2,203,101);
Insert into FACT_SALE (ID_SALE,TOTAL,DIM_ITEM_ID_ITEM,DIM_TIME_ID_TIME,DIM_PLACE_ID_PLACE) values ('1009 ',130000,1,204,100);
Insert into FACT_SALE (ID_SALE,TOTAL,DIM_ITEM_ID_ITEM,DIM_TIME_ID_TIME,DIM_PLACE_ID_PLACE) values ('1010 ',144000,1,204,100);
Insert into FACT_SALE (ID_SALE,TOTAL,DIM_ITEM_ID_ITEM,DIM_TIME_ID_TIME,DIM_PLACE_ID_PLACE) values ('1011 ',490000,2,203,101);
Insert into FACT_SALE (ID_SALE,TOTAL,DIM_ITEM_ID_ITEM,DIM_TIME_ID_TIME,DIM_PLACE_ID_PLACE) values ('1012 ',151600,3,202,102);
Insert into FACT_SALE (ID_SALE,TOTAL,DIM_ITEM_ID_ITEM,DIM_TIME_ID_TIME,DIM_PLACE_ID_PLACE) values ('1013 ',852600,4,201,103);
Insert into FACT_SALE (ID_SALE,TOTAL,DIM_ITEM_ID_ITEM,DIM_TIME_ID_TIME,DIM_PLACE_ID_PLACE) values ('1014 ',267000,5,200,104);
Insert into FACT_SALE (ID_SALE,TOTAL,DIM_ITEM_ID_ITEM,DIM_TIME_ID_TIME,DIM_PLACE_ID_PLACE) values ('1015 ',294000,5,200,104);

Insert into FACT_SALE (ID_SALE,TOTAL,DIM_ITEM_ID_ITEM,DIM_TIME_ID_TIME,DIM_PLACE_ID_PLACE) values ('1016 ',963000,4,201,103);
Insert into FACT_SALE (ID_SALE,TOTAL,DIM_ITEM_ID_ITEM,DIM_TIME_ID_TIME,DIM_PLACE_ID_PLACE) values ('1017 ',738000,3,202,102);
Insert into FACT_SALE (ID_SALE,TOTAL,DIM_ITEM_ID_ITEM,DIM_TIME_ID_TIME,DIM_PLACE_ID_PLACE) values ('1018 ',375000,2,203,101);
Insert into FACT_SALE (ID_SALE,TOTAL,DIM_ITEM_ID_ITEM,DIM_TIME_ID_TIME,DIM_PLACE_ID_PLACE) values ('1019 ',840000,1,204,100);


select dim_item_id_item, dim_place_id_place, sum(total) as price
from fact_sale
group by rollup(dim_item_id_item,dim_place_id_place);

select dim_item.item_name, dim_place.shopname, sum(total) as price
from fact_sale, dim_item, dim_place
where fact_sale.dim_item_id = dim_item.id_item and fact_sale.dim_place_id_place = dim.place.id_place
group by rollup(dim_item.item_name, dim_place.shopname);

select dim_item.item_name, dim_place.city, dim_time.yearmonth, sum(total) as price
from fact_sale, dim_item, dim_place, dim_time
group by rollup(dim_item.item_name, dim_place.city, dim_time.yearmonth);

select dim_item_id_item, dim_place_id_place, sum(total) as price
from fact_sale
group by cube(dim_item_id_item, dim_place_id_place)
order by dim_item_id_item, dim_place_id_place;

select dim_item.item_name, dim_place.shopname, sum(total) as price
from fact_sale, dim_item, dim_place
where fact_sale.dim_item_id_item = dim_item.id_item and fact_sale.dim_place_id_place = dim_place.id_place
group by cube(dim_item.item_name, dim_place.shopname)
order by dim_item.item_name, dim_place.shopname;

select dim_item.item_name, dim_place.city, dim_time.yearmonth, sum(total) as price
from fact_sale, dim_item, dim_place, dim_time
where fact_sale.dim_item_id_item = dim_item.id_item and fact_sale.dim_place_id_place = dim_place.id_place and fact_sale.dim_time_id_time = dim_time.id_time
group by cube(dim_item.item_name, dim_place.city, dim_time.yearmonth)
order by dim_item.item_name, dim_place.city, dim_time.yearmonth;

select dim_item.color, dim_place.country, dim_time.yearmonth, sum(total) as price
from fact_sale, dim_item, dim_place, dim_time
where fact_sale.dim_item_id_item = dim_item.id_item and fact_sale.dim_place_id_place = dim_place.id_place and fact_sale.dim_time_id_time = dim_time.id_time
group by cube(dim_item.color, dim_place.country, dim_time.yearmonth)
order by dim_item.color, dim_place.country, dim_time.yearmonth;

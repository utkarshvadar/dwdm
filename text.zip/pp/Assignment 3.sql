create table dim_customer
(
  customer_id int primary key,
  customer_alt_id varchar(10) not null,
  customer_name varchar(100),
  gender varchar(20)
);

insert into dim_customer values(1,'ABC-001','Jinesh Nadar','M');
insert into dim_customer values(2,'ABC-002','Sumant Wadekar','M');
insert into dim_customer values(3,'ABC-003','Pooja Mule','F');
insert into dim_customer values(4,'ABC-004','Santosh Guttigoli','M');
insert into dim_customer values(5,'ABC-005','Akshay Bhagwat','M');
  
create table dim_product
(
  product_id int primary key,
  product_alt_key varchar(10) not null,
  product_name varchar(10),
  product_cost_price int,
  product_selling_price int
);
--truncate  table dim_product;
insert into dim_product values(11,'ITEM-001','Soya Oil',10,20);  
insert into dim_product values(12,'ITEM-002','Umbrella',100,150);
insert into dim_product values(13,'ITEM-003','Soap',20,23);
insert into dim_product values(14,'ITEM-004','Sleeper',500,550);
insert into dim_product values(15,'ITEM-005','Nirma',56,60);  

create table dim_stores
(
  store_id int primary key,
  store_alt_id varchar(10) not null,
  store_name varchar(100),
  store_location varchar(100),
  city varchar(100),
  state varchar(100),
  country varchar(100)
);

insert into dim_stores values(111,'LOC-1','X_mart','SP Road','udgir','Maharashtra','India');
insert into dim_stores values(112,'LOC-2','X_mart','Bapat Road','Latur','Maharashtra','India');
insert into dim_stores values(113,'LOC-3','X_mart','Bidar Road','Dhamangaon','Maharashtra','India');

create table dim_sales_person 
(
  sales_person_id int primary key,
  sales_person_alt_id varchar(10) not null,
  sales_person_name varchar(50),
  store_id int,
  city varchar(100),
  state varchar(100),
  country varchar(100)
);

insert into DIM_SALES_PERSON VALUES (1111,'DMSPR1','Ashish',1,'Varanasi','UP','IND');
insert into DIM_SALES_PERSON VALUES (1112,'DMSPR2','Ajay',1,'Varanasi','UP','IND');
insert into DIM_SALES_PERSON VALUES (1113,'DMNGR1','Shreeram',2,'Varanasi','UP','IND');
insert into DIM_SALES_PERSON VALUES (1114,'DMNGR2','Ajit',2,'Varanasi','UP','IND');
insert into DIM_SALES_PERSON VALUES (1115,'DMSVR1','Neha',3,'Varanasi','UP','IND');
insert into DIM_SALES_PERSON VALUES (1116,'DMSVR2','Jack',3,'Varanasi','UP','IND');


CREATE TABLE dim_time(
	time_id int primary key,
	time_alt_id int NOT NULL,
	time_30 varchar(8) NOT NULL,
	hour_30 int NOT NULL,
	minute_number int NOT NULL,
	second_number int NOT NULL,
	time_in_second int NOT NULL,
	hourly_bucket varchar(15)not null,
	day_time_bucket_group_key int not null,
	day_time_bucket varchar(100) not null
);

INSERT INTO DIM_TIME (TIME_ID,TIME_ALT_ID, TIME_30,HOUR_30,MINUTE_NUMBER, SECOND_NUMBER, TIME_IN_SECOND,HOURLY_BUCKET, DAY_TIME_BUCKET_GROUP_KEY,DAY_TIME_BUCKET)
values(1,30000,'3:00:00',3,00,00,10800,'3:00-3:59',1,'Early Morning(03:00 AM To 6:59 AM)');


INSERT INTO DIM_TIME (TIME_ID,TIME_ALT_ID, TIME_30,HOUR_30,MINUTE_NUMBER, SECOND_NUMBER, TIME_IN_SECOND,HOURLY_BUCKET, DAY_TIME_BUCKET_GROUP_KEY,DAY_TIME_BUCKET)
values(2,121000,'12:10:00',12,10,00,43800,'12:00-12:59',4,'Lunch (12:00 PM To 13:59 PM)');

Create Table FactProductSales
(
TransactionId int primary key,
SalesInvoiceNumber int not null,
SalesDateKey int,
SalesTimeKey int,
SalesTimeAltKey int,
StoreID int not null,
CustomerID int not null,
ProductID int not null,
SalesPersonID int not null,
Quantity float,
SalesTotalCost int,
ProductActualCost int,
Deviation float,
FOREIGN KEY(StoreID)REFERENCES dim_stores(store_id),
FOREIGN KEY (CustomerID)REFERENCES dim_customer(customer_id),
FOREIGN KEY (ProductID)REFERENCES dim_product(product_id),
FOREIGN KEY (SalesPersonID)REFERENCES dim_sales_person(sales_person_id)
);

INSERT INTO FactProductSales values(11111,20130101,44347,121907,1219070,111,1,11,1111,20,11000,10000,1000);
INSERT INTO FactProductSales values(11112,20130102,44348,121908,1219080,112,2,12,1112,30,12000,10000,2000);
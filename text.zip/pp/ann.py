import numpy as np

class NeuralNetwork:
	def __init__(self,alpha,iterations,input_nodes,hidden_nodes1,hidden_nodes2,output_nodes):
		self.alpha = alpha
		self.input_nodes = input_nodes
		self.hidden_nodes1 = hidden_nodes1
		self.hidden_nodes2 = hidden_nodes2
		self.output_nodes = output_nodes
		self.iterations = iterations
		#now make thetas
		# use numpy's normal function
		# np.random.normal(mean of destribution,range,samples)

		self.theta1 = np.random.normal(0.0,1,(input_nodes+1,hidden_nodes1))
		self.theta2 = np.random.normal(0.0,1,(hidden_nodes1+1,hidden_nodes2))
		self.theta3 = np.random.normal(0.0,1,(hidden_nodes2+1,output_nodes))
	def sigmoid(self,X):
		return 1/(1+np.exp(-X))

	def inv_sigmoid(self,X):
		X = sigmoid(X)
		return X*(1-X)

	def train(self,X,y):
		# add bias
		m = len(X[:,0])
		tmp = np.ones((m,1))
		X = np.append(tmp,X,axis = 1)

		# get transposes
		Xt = X.T
		yt = y.T
		#start forward and backward propagation
		for i in range(self.iterations):

			hidden_out1 = X.dot(self.theta1)
			hidden_output_without_bias1 = self.sigmoid(hidden_out1)
			hidden_output_with_bias1 = np.append(tmp,hidden_output_without_bias1,axis = 1)  # add bias

			hidden_out2 = hidden_output_with_bias1.dot(self.theta2)
			hidden_output_without_bias2 = self.sigmoid(hidden_out2)
			hidden_output_with_bias2 = np.append(tmp,hidden_output_without_bias2,axis = 1)

			out = hidden_output_with_bias2.dot(self.theta3)
			output = self.sigmoid(out)

			error = y - output                        # 100 x 10
			hidden_error2 = error.dot(self.theta3.T)	   # 100 x 501
			hidden_error1 = hidden_error2.dot(self.theta2)

			self.theta3 += self.alpha * (np.dot(hidden_output_with_bias2.T,(error * output * (1.0 - output))))
			self.theta2 += self.alpha * (np.dot(hidden_output_with_bias1.T,(hidden_error2[:,1:] * hidden_output_without_bias2 * (1.0 - hidden_output_without_bias2))))
			self.theta1 += self.alpha * (np.dot(Xt,(hidden_error1 * hidden_output_without_bias1 * (1.0 - hidden_output_without_bias1))))
			
			return error

	def test(self,X):
		# add bias
		m = len(X[:,0])
		tmp = np.ones((m,1))
		X = np.append(tmp,X,axis = 1)
		Xt = X.T

		
		hidden_out = X.dot(self.theta1)
		hidden_output_without_bias1 = self.sigmoid(hidden_out)
		hidden_output_with_bias1 = np.append(tmp,hidden_output_without_bias1,axis = 1)  # add bias

		hidden_out2 = hidden_output_with_bias1.dot(self.theta2)
		hidden_output_without_bias2 = self.sigmoid(hidden_out2)
		hidden_output_with_bias2 = np.append(tmp,hidden_output_without_bias2,axis = 1)

		out = hidden_output_with_bias2.dot(self.theta3)
		output = self.sigmoid(out)
		predicted = [0]*m
		for i in range(m):
			predicted[i] = output[i].tolist().index(max(output[i]))
		return predicted

	def progbar(self,curr, total, full_progbar):
	    frac = curr/total
	    filled_progbar = round(frac*full_progbar)
	    print('\r\t', '█'*filled_progbar + '-'*(full_progbar-filled_progbar), '[{:>7.2%}]'.format(frac), end='')

print("data loading...")
data = np.genfromtxt("mnist_dataset/mnist_train_100.csv",delimiter = ',')
#test = np.genfromtxt("mnist_dataset/mnist_test.csv",delimiter = ',')
nn = NeuralNetwork(0.3,20,784,16,16,10)  #object created
print("completed")

y = data[:,0]
X = data[:,1:785]
print(X.dtype)
m = len(y)
print("m: ",m)
Y = np.array([[0]*10]*m)
for i in range(m):
	Y[i,int(y[i])] = 1

for i in range(m):
	for j in range(784):
		if X[i,j] == 0:
			X[i,j] = 0.01
while True:
	print("first training started")
	#for i in range(0,m,2):
	nn.train(X/255,Y[i])
	print("training completed")



	pre = nn.test(X)
	count =0
	print("testing on training data")
	for i in range(m):
		if y[i]!=pre[i]:
			#print(y[i],pre[i])
			count += 1
	print('Error',count)
	if input()=='0':
		break
'''
X_test = test[:,1:]
y_test = test[:,0]
m_test = len(y_test)

print("testing test data started on",m_test,"data points")
predicted = nn.test(X_test/255000)
print("testing completed")

count = 0
for i in range(m_test):
	if y_test[i]!=predicted[i]:
		#print(y_test[i],predicted[i])
		count += 1
	#else:
		#print("\t", y_test[i],predicted[i])

	
print("error in prediction:",(count/m_test)*100)

'''